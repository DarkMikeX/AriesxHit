# Installation

1. Open Chrome → `chrome://extensions`
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select the `ext` folder

Use the ✦ button on any page to open the panel. For Telegram login and hit notifications, run the backend and add `TELEGRAM_BOT_TOKEN` to `.env` (see `backend/docs/TELEGRAM_SETUP.md`).
